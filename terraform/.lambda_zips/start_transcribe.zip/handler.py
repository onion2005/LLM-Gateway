import boto3
import os
import time
import urllib.parse

def handler(event, context):
    record  = event["Records"][0]
    bucket  = record["s3"]["bucket"]["name"]
    key     = urllib.parse.unquote_plus(record["s3"]["object"]["key"])

    # Derive a stable job name from the S3 key + timestamp
    safe_key = key.replace("/", "-").replace(".", "-").replace(" ", "-")
    job_name = f"{safe_key}-{int(time.time())}"[:200]  # Transcribe limit

    # Detect media format from extension
    ext = key.rsplit(".", 1)[-1].lower()
    fmt_map = {"mp4": "mp4", "mp3": "mp3", "wav": "wav",
               "flac": "flac", "ogg": "ogg", "amr": "amr", "webm": "webm"}
    media_format = fmt_map.get(ext, "mp4")

    transcribe = boto3.client("transcribe")
    transcribe.start_transcription_job(
        TranscriptionJobName=job_name,
        Media={"MediaFileUri": f"s3://{bucket}/{key}"},
        MediaFormat=media_format,
        LanguageCode="zh-CN",
        OutputBucketName=bucket,
        OutputKey=f"transcripts/{job_name}.json",
    )

    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(os.environ["DYNAMODB_TABLE"])
    table.put_item(Item={
        "job_id":            job_name,
        "status":            "IN_PROGRESS",
        "source_s3_key":     key,
        "transcript_s3_key": f"transcripts/{job_name}.json",
        "created_at":        int(time.time()),
    })

    print(f"Started transcription job: {job_name}")
    return {"job_id": job_name}
