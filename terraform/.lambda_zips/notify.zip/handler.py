import boto3
import os
import time

def handler(event, context):
    detail   = event["detail"]
    job_name = detail["TranscriptionJobName"]
    status   = detail["TranscriptionJobStatus"]  # COMPLETED or FAILED

    dynamodb = boto3.resource("dynamodb")
    table = dynamodb.Table(os.environ["DYNAMODB_TABLE"])
    table.update_item(
        Key={"job_id": job_name},
        UpdateExpression="SET #s = :s, updated_at = :t",
        ExpressionAttributeNames={"#s": "status"},
        ExpressionAttributeValues={":s": status, ":t": int(time.time())},
    )

    print(f"Job {job_name} → {status}")
    return {"job_id": job_name, "status": status}
